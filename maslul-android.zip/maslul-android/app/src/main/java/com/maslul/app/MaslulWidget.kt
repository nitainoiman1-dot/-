package com.maslul.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject

/** ווידג'ט "מסלול": היום במבט אחד. הנתונים מגיעים מהאתר (MainActivity.Bridge.saveSummary). */
class MaslulWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    companion object {
        private const val DAY_MS = 24L * 60 * 60 * 1000

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, MaslulWidget::class.java))
            ids.forEach { update(context, manager, it) }
        }

        private fun open(context: Context, code: Int, go: String?): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (go != null) putExtra("go", go)
            }
            return PendingIntent.getActivity(
                context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun set(v: RemoteViews, id: Int, text: String) {
            if (text.isEmpty()) {
                v.setViewVisibility(id, View.GONE)
            } else {
                v.setViewVisibility(id, View.VISIBLE)
                v.setTextViewText(id, text)
            }
        }

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val v = RemoteViews(context.packageName, R.layout.widget)
            val raw = context.getSharedPreferences("maslul", Context.MODE_PRIVATE).getString("summary", null)
            val s = try { if (raw != null) JSONObject(raw) else null } catch (e: Exception) { null }
            val fresh = s != null && System.currentTimeMillis() - s.optLong("ts") < DAY_MS

            if (s == null || !fresh) {
                set(v, R.id.w_title, context.getString(R.string.widget_open_title))
                set(v, R.id.w_tasks, context.getString(R.string.widget_open_hint))
                set(v, R.id.w_lesson, "")
                set(v, R.id.w_exam, "")
            } else {
                set(v, R.id.w_title, s.optString("greet") + ", " + s.optString("date"))
                val total = s.optInt("total")
                val done = s.optInt("done")
                set(
                    v, R.id.w_tasks,
                    (if (total > 0) "משימות: $done מתוך $total" else "אין משימות להיום") +
                        "  ·  ${s.optInt("pts")} נקודות  ·  רצף ${s.optInt("streak")}"
                )
                set(v, R.id.w_lesson, s.optString("lesson"))
                set(v, R.id.w_exam, s.optString("exam"))
            }

            v.setOnClickPendingIntent(R.id.root, open(context, 0, null))
            v.setOnClickPendingIntent(R.id.w_btn_chal, open(context, 1, "challenge"))
            v.setOnClickPendingIntent(R.id.w_btn_tasks, open(context, 2, "maslul:home"))
            v.setOnClickPendingIntent(R.id.w_btn_words, open(context, 3, "vocab:tr"))
            manager.updateAppWidget(id, v)
        }
    }
}

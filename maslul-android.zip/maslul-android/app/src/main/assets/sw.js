/* מאפשר עבודה בלי אינטרנט. קודם מהזיכרון, ומעדכן ברקע. */
var VER='maslul-v4';
var CORE=['./','index.html','maslul.html','vocab.html','school.css','app.css','app.js','bridge.js','bridge-maslul.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/apple-touch-icon.png'];
self.addEventListener('install',function(e){
  e.waitUntil(caches.open(VER).then(function(c){return Promise.all(CORE.map(function(u){return c.add(u).catch(function(){})}))}).then(function(){return self.skipWaiting()}));
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==VER}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}));
});
self.addEventListener('fetch',function(e){
  var r=e.request;
  if(r.method!=='GET')return;
  var u=new URL(r.url);
  var sameOrigin=u.origin===self.location.origin;
  var fonts=u.hostname==='fonts.googleapis.com'||u.hostname==='fonts.gstatic.com';
  if(!sameOrigin&&!fonts)return;
  e.respondWith(caches.open(VER).then(function(c){
    return c.match(r,{ignoreSearch:true}).then(function(hit){
      var net=fetch(r).then(function(res){if(res&&(res.status===200||res.type==='opaque'))c.put(r,res.clone());return res}).catch(function(){return hit});
      return hit||net.then(function(res){return res||c.match('index.html')});
    });
  }));
});

(function(){
'use strict';
var $=function(s,r){return(r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var shuffle=function(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t}return a};
var ymd=function(d){d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
function lsGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{localStorage.setItem(k,v)}catch(e){}}
function lsDel(k){try{localStorage.removeItem(k)}catch(e){}}
function jget(k,d){try{var v=JSON.parse(lsGet(k));return v==null?d:v}catch(e){return d}}

var ICON={
  list:'<path d="M9 6h11M9 12h11M9 18h11M3.5 6l1.5 1.5L7.5 5M3.5 12l1.5 1.5L7.5 11M3.5 18l1.5 1.5L7.5 17"/>',
  timer:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/>',
  trans:'<path d="m5 8 6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6"/>',
  game:'<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01M17.32 5H6.68a4 4 0 0 0-3.98 3.59C2.6 9.42 2 14.46 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.41-1.41A2 2 0 0 1 9.83 16h4.34a2 2 0 0 1 1.42.59L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.54-.6-6.58-.7-7.41A4 4 0 0 0 17.32 5z"/>',
  cap:'<path d="M21.42 10.92a1 1 0 0 0-.02-1.84L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0zM22 10v6M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>',
  gift:'<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
  bolt:'<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>'
};
var ic=function(k){return '<svg class="i" viewBox="0 0 24 24">'+ICON[k]+'</svg>'};
var STAR='<svg viewBox="0 0 24 24"><path d="M12 2.6l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.4 1.3-6.6L2.5 9.5l6.6-.8z" fill="currentColor" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/></svg>';

/* ---------- גשר לאפליקציות הפנימיות ---------- */
var frames={maslul:$('#f-maslul'),vocab:$('#f-vocab')};
var ready={maslul:false,vocab:false};
var seq=0,pending={};
window.addEventListener('message',function(e){
  var m=e.data; if(!m||m.__maslul!==1)return;
  if(e.source!==frames.maslul.contentWindow&&e.source!==frames.vocab.contentWindow)return;
  if(m.t==='ready'){ready[m.app]=true;return}
  if(m.t==='award'){shareAward(m.n,m.src);return}
  if(m.id&&pending[m.id]){var f=pending[m.id];delete pending[m.id];f(m)}
});
function ask(app,msg,ms){
  return new Promise(function(res){
    var id=++seq; msg.id=id; msg.__maslul=1;
    var to=setTimeout(function(){delete pending[id];res(null)},ms||2500);
    pending[id]=function(m){clearTimeout(to);res(m)};
    try{frames[app].contentWindow.postMessage(msg,'*')}catch(e){clearTimeout(to);delete pending[id];res(null)}
  });
}
function waitReady(app,ms){
  return new Promise(function(res){var t0=Date.now();(function chk(){if(ready[app])return res(true);if(Date.now()-t0>(ms||6000))return res(false);setTimeout(chk,120)})()});
}
function shareAward(n,src){
  ask('maslul',{t:'award',n:n,why:src==='vocab'?'אוצר המילים':''}).then(function(){
    toast('+'+n+' נקודות גם במסלול');refreshHead();
  });
}
function award(n,why){return ask('maslul',{t:'award',n:n,why:why})}

/* ---------- ניווט ---------- */
var VIEW='home';
function go(v,sub){
  VIEW=v;
  $$('.bt').forEach(function(b){b.setAttribute('aria-selected',b.dataset.v===v?'true':'false')});
  ['home','report'].forEach(function(k){$('#v-'+k).hidden=(k!==v)});
  ['maslul','vocab'].forEach(function(k){$('#f-'+k).hidden=(k!==v)});
  if(v==='home')renderHome();
  if(v==='report')renderReport();
  if(sub&&(v==='maslul'||v==='vocab'))waitReady(v).then(function(){ask(v,{t:'tab',tab:sub})});
  lsSet('school.view',v);
}
$$('.bt').forEach(function(b){b.addEventListener('click',function(){go(b.dataset.v)})});
document.addEventListener('visibilitychange',function(){if(!document.hidden&&(VIEW==='home'||VIEW==='report'))go(VIEW)});

/* ---------- נתונים ---------- */
var DATA={sum:null,voc:null};
function loadData(){
  return Promise.all([waitReady('maslul'),waitReady('vocab')]).then(function(){return Promise.all([
    ask('maslul',{t:'summary'}),
    ask('vocab',{t:'summary'})
  ])}).then(function(r){
    DATA.sum=r[0]&&r[0].data||null;
    var voc=null;try{voc=r[1]&&r[1].raw?JSON.parse(r[1].raw):null}catch(e){}
    DATA.voc=voc&&voc.words?voc:null;
    pushWidget();
    return DATA;
  });
}
function refreshHead(){}
/* ווידג'ט באפליקציית אנדרואיד: שולח סיכום קצר לצד הנייטיבי (לא עושה כלום בדפדפן רגיל) */
function pushWidget(){
  try{
    if(!window.AndroidBridge||!DATA.sum)return;
    var s=DATA.sum,ex=s.exams&&s.exams[0],l=s.lesson,les='';
    if(l){les=l.k==='now'?'עכשיו: '+l.name:l.k==='next'?'הבא: '+l.name+' בשעה '+l.at:'יום הלימודים הסתיים'}
    window.AndroidBridge.saveSummary(JSON.stringify({
      ts:Date.now(),date:new Date().toLocaleDateString('he-IL',{weekday:'long',day:'numeric',month:'long'}),greet:GREET(),
      done:s.done,total:s.total,pts:s.pts,streak:s.streak,lvl:s.lvl,lesson:les,exam:ex?('מבחן '+ex.name+' '+leftTxt(ex.days)):''
    }));
  }catch(e){}
}
var GREET=function(){var h=new Date().getHours();return h<5?'לילה טוב':h<12?'בוקר טוב':h<17?'צהריים טובים':h<21?'ערב טוב':'לילה טוב'};
var dayNum=function(){var n=new Date();return Math.floor(Date.UTC(n.getFullYear(),n.getMonth(),n.getDate())/864e5)};
var leftTxt=function(n){return n<=0?'היום':n===1?'מחר':n===2?'מחרתיים':'בעוד '+n+' ימים'};

/* ---------- מסך הבית ---------- */
var daily=function(){return jget('school.daily',{})};
function renderHome(){
  var host=$('#v-home');
  host.innerHTML='<div class="page"><div class="card empty">טוען את היום שלך…</div></div>';
  loadData().then(function(){ if(VIEW!=='home')return; host.innerHTML='<div class="page">'+homeHTML()+'</div>'; bindHome(host); });
}
function homeHTML(){
  var s=DATA.sum,v=DATA.voc,d=daily(),today=ymd();
  var h='';
  // לוח
  if(s){
    var C=2*Math.PI*33,off=C*(1-(s.total?s.done/s.total:0));
    var l1='',l2='';
    if(s.lesson&&s.lesson.k==='now'){l1='עכשיו: '+esc(s.lesson.name);l2='עוד '+s.lesson.left+' דק׳ עד הצלצול'}
    else if(s.lesson&&s.lesson.k==='next'){l1='הבא: '+esc(s.lesson.name);l2='בעוד '+s.lesson.in+' דק׳, בשעה '+esc(s.lesson.at)}
    else if(s.lesson&&s.lesson.k==='over'){l1='יום הלימודים הסתיים';l2=(s.total-s.done>0)?'נשארו '+(s.total-s.done)+' משימות להיום':'סיימת את כל המשימות להיום'}
    else if(s.day<0){l1='שבת, יום מנוחה';l2='נטען כוחות לשבוע החדש'}
    else{l1='מה עושים היום?';l2=s.total?('נשארו '+(s.total-s.done)+' מתוך '+s.total+' משימות'):'עוד אין משימות להיום'}
    var ex=s.exams.map(function(e){return '<button class="ex'+(e.days<=2?' hot':'')+'" data-go="maslul:subj"><b>'+esc(e.name)+'</b><span>מבחן '+leftTxt(e.days)+'</span></button>'}).join('');
    h+='<section class="board deck"><div class="btop"><div class="pr"><svg viewBox="0 0 78 78" aria-hidden="true"><circle class="bg" cx="39" cy="39" r="33"/><circle class="fg" cx="39" cy="39" r="33" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'"/></svg><b>'+s.done+'/'+s.total+'</b></div>'+
      '<div><h2>'+GREET()+'!</h2><p><b>'+l1+'</b><br>'+l2+'</p></div></div>'+
      '<div class="bstats"><div><b>'+s.lvl+'</b><span>דרגה · '+esc(s.lvlName)+'</span></div><div><b>'+s.pts+'</b><span>נקודות</span></div><div><b>'+s.streak+'</b><span>ימי רצף</span></div></div>'+
      (ex?'<div class="exams">'+ex+'</div>':'')+'</section>';
  }else{
    h+='<section class="board deck"><h2>'+GREET()+'!</h2><p>המסלול נטען, שנייה…</p></section>';
  }
  // אתגר יומי
  var doneToday=d.d===today;
  h+='<section class="card"><div class="chal'+(doneToday?' done':'')+'"><div class="badge">'+(doneToday?'<svg class="i" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>':ic('bolt'))+'</div>'+
    '<div class="grow"><b>אתגר היום</b><span class="muted small">'+(doneToday?('סיימת: '+d.score+' מתוך '+d.of+'. רצף אתגרים: '+(d.streak||1)+(d.streak>1?' ימים':' יום')):'5 שאלות מהמילים ומהחומר שלך. נקודות על כל תשובה נכונה.')+'</span></div></div>'+
    '<div class="btns" style="margin-top:12px"><button class="btn primary" data-act="challenge">'+(doneToday?'עוד סיבוב (בלי נקודות)':'מתחילים')+'</button></div></section>';
  // פעולות
  var acts=[['list','המשימות שלי','maslul:home','#E2562B'],['timer','שעון ריכוז','maslul:time','#E2562B'],['gift','פרסים','maslul:shop','#E2562B'],
            ['trans','תרגום מילה','vocab:tr','#3E7BE0'],['game','משחקי מילים','vocab:game','#3E7BE0'],['cap','המורה','vocab:tutor','#3E7BE0']];
  h+='<section class="acts">'+acts.map(function(a){return '<button class="act" style="--tc:'+a[3]+'" data-go="'+a[2]+'">'+ic(a[0])+'<span>'+a[1]+'</span></button>'}).join('')+'</section>';
  // מילת היום
  if(v&&v.words.length){
    var w=v.words[(dayNum()*7)%v.words.length];
    h+='<section class="card"><h2>מילת היום</h2><button class="flip" data-act="flip" aria-live="polite"><div class="w" dir="auto">'+esc(w.src)+'</div><div class="t" hidden dir="auto">'+esc(w.he)+'</div><div class="h">לחץ כדי לראות את התרגום</div></button></section>';
  }
  // פתק מהמחברת
  h+='<section class="note">'+esc(noteText())+'</section>';
  h+=installHTML();
  return h;
}
function noteText(){
  var s=DATA.sum,v=DATA.voc;
  var pool=['כל יום קצת, וזה מצטבר להרבה.','מי שחוזר על החומר ישן טוב יותר בלילה לפני המבחן.','טעות היא רק מילה שעוד לא למדת.'];
  if(s&&s.streak>=3)pool.unshift('רצף של '+s.streak+' ימים! אל תשבור אותו עכשיו.');
  if(s&&s.exams.length&&s.exams[0].days<=3)pool.unshift('המבחן ב'+s.exams[0].name+' קרוב. 20 דקות היום שוות יותר מלילה שלם בסוף.');
  if(s&&s.total&&s.done===s.total)pool.unshift('כל המשימות להיום הושלמו. כל הכבוד!');
  if(v&&v.words.length>=5)pool.push('יש לך כבר '+v.words.length+' מילים במילון. זה אוצר אמיתי.');
  return pool[dayNum()%pool.length];
}
function bindHome(host){
  host.addEventListener('click',function(e){
    var g=e.target.closest('[data-go]'),a=e.target.closest('[data-act]');
    if(g){var p=g.dataset.go.split(':');go(p[0],p[1]);return}
    if(a){
      if(a.dataset.act==='flip'){var t=$('.t',a),h=$('.h',a);t.hidden=!t.hidden;h.hidden=!t.hidden}
      else if(a.dataset.act==='challenge')startChallenge();
      else if(a.dataset.act==='install')doInstall();
    }
  });
}

/* ---------- התקנה כאפליקציה ---------- */
var deferred=null;
window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();deferred=e;if(VIEW==='home')renderHome()});
window.addEventListener('appinstalled',function(){deferred=null;toast('האפליקציה הותקנה!');if(VIEW==='home')renderHome()});
var isStandalone=function(){return (window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true};
var isIOS=function(){return /iphone|ipad|ipod/i.test(navigator.userAgent)};
function installHTML(){
  if(isStandalone())return '';
  if(deferred)return '<section class="card"><h2>להתקין כאפליקציה</h2><p class="muted small" style="margin:0 0 10px">האפליקציה תעבוד גם בלי אינטרנט ותופיע במסך הבית.</p><button class="btn primary block" data-act="install">התקן עכשיו</button></section>';
  if(isIOS())return '<section class="card"><h2>להתקין כאפליקציה</h2><p class="muted small" style="margin:0">בספארי: לחץ על כפתור השיתוף ואז על "הוסף למסך הבית".</p></section>';
  return '';
}
function doInstall(){if(!deferred)return;deferred.prompt();deferred.userChoice.finally(function(){deferred=null;renderHome()})}

/* ---------- תעודה ---------- */
var gradeOf=function(p){return p==null?{t:'—',c:'#8A8A80'}:p>=85?{t:'מצוין',c:'#19A974'}:p>=70?{t:'טוב מאוד',c:'#4CAF50'}:p>=55?{t:'טוב',c:'#E8A317'}:p>=40?{t:'מספיק',c:'#E2762B'}:{t:'דרוש חיזוק',c:'#C23A4B'}};
function renderReport(){
  var host=$('#v-report');
  host.innerHTML='<div class="page"><div class="card empty">מכין את התעודה…</div></div>';
  loadData().then(function(){ if(VIEW!=='report')return; host.innerHTML='<div class="page">'+reportHTML()+'</div>'});
}
function reportHTML(){
  var s=DATA.sum,v=DATA.voc,rows='',vals=[];
  if(s){
    s.subjects.forEach(function(x){
      var g=gradeOf(x.ready);if(x.ready!=null)vals.push(x.ready);
      rows+='<div class="gr"><span class="nm">'+esc(x.name)+'</span><span class="g" style="color:'+g.c+'">'+g.t+(x.ready!=null?' · '+x.ready+'%':'')+'</span><span class="meter"><i style="width:'+(x.ready||0)+'%;background:'+g.c+'"></i></span></div>';
    });
  }
  if(!rows)rows='<div class="empty">עוד אין מקצועות. הוסף מבחן במסלול, סמן כמה נושאים שאתה שולט בהם, והציון יופיע כאן.</div>';
  var vh='';
  if(v&&v.words.length){
    var known=v.words.filter(function(w){return w.known}).length,pct=Math.round(known/v.words.length*100),g=known>0?gradeOf(pct):{t:'עוד לא סימנת',c:'#8A8A80'};
    if(known>0)vals.push(pct);
    vh='<div class="gr"><span class="nm">מילים שאני יודע</span><span class="g" style="color:'+g.c+'">'+g.t+(known>0?' · '+pct+'%':'')+'</span><span class="meter"><i style="width:'+pct+'%;background:'+g.c+'"></i></span></div>'+
       '<div class="gr"><span class="nm">מילים במילון</span><span class="g">'+v.words.length+'</span></div>'+
       '<div class="gr"><span class="nm">כוכבים שהרווחתי</span><span class="g">'+(v.stars||0)+'</span></div>';
  }else vh='<div class="empty">המילון עוד ריק. הוסף מילים בלשונית "מילים".</div>';
  var hab='';
  if(s){
    var acc=s.reviews?Math.round(s.correct/s.reviews*100):null;
    hab='<div class="gr"><span class="nm">התמדה (ימים ברצף)</span><span class="g">'+s.streak+'</span></div>'+
        '<div class="gr"><span class="nm">דקות ריכוז</span><span class="g">'+s.focus+'</span></div>'+
        '<div class="gr"><span class="nm">דיוק בתרגול</span><span class="g">'+(acc==null?'—':acc+'%')+'</span></div>'+
        '<div class="gr"><span class="nm">תגים שנאספו</span><span class="g">'+s.badges+'</span></div>'+
        '<div class="gr"><span class="nm">דרגה</span><span class="g">'+s.lvl+' · '+esc(s.lvlName)+'</span></div>';
  }
  var avg=vals.length?Math.round(vals.reduce(function(a,b){return a+b},0)/vals.length):null;
  var cm;
  if(avg==null)cm='תלמיד חדש בכיתה. מחכה לראות את ההתחלה!';
  else if(avg>=85)cm='עבודה מצוינת! שליטה בחומר ועקביות. ממשיכים ככה.';
  else if(avg>=70)cm='התקדמות יפה מאוד. קצת חזרה על הנושאים החלשים והציונים יקפצו.';
  else if(avg>=50)cm='יש בסיס טוב. כדאי לקבוע זמן קבוע ביום לחזרה קצרה.';
  else cm='ההתחלה היא החלק הכי קשה, וכבר התחלת. בוא נתמקד בנושא אחד בכל פעם.';
  if(s&&s.streak>=5)cm+=' התמדה יוצאת דופן!';
  var date=new Date().toLocaleDateString('he-IL',{day:'numeric',month:'long',year:'numeric'});
  return '<section class="rc">'+(avg!=null&&avg>=80?'<div class="stamp">מעולה!</div>':'')+'<h1>תעודה</h1><div class="sub">'+esc(date)+(avg!=null?' · ממוצע '+avg:'')+'</div>'+
    '<h3>מקצועות</h3>'+rows+'<h3>אוצר המילים</h3>'+vh+'<h3>הרגלי למידה</h3>'+hab+
    '<h3>הערת המחנכת</h3><div class="cmt">'+esc(cm)+'</div><div class="sig"><span>חתימת מחנכת</span><span>חתימת הורה</span></div></section>';
}

/* ---------- אתגר יומי ---------- */
var CH=null;
function buildQuestions(){
  var out=[],words=(DATA.voc&&DATA.voc.words)||[],qs=(DATA.sum&&DATA.sum.qs)||[];
  var vq=[];
  if(words.length>=4){
    shuffle(words).slice(0,8).forEach(function(w){
      var toHe=Math.random()<.5,ans=toHe?w.he:w.src,q=toHe?w.src:w.he;
      var pool=shuffle(words.filter(function(x){return x.id!==w.id&&(toHe?x.he:x.src)!==ans})).map(function(x){return toHe?x.he:x.src});
      var seen={},opts=[];pool.forEach(function(t){if(!seen[t]&&opts.length<3){seen[t]=1;opts.push(t)}});
      if(opts.length<3)return;
      opts.push(ans);opts=shuffle(opts);
      vq.push({src:'מילים',q:(toHe?'מה התרגום של ':'איך אומרים ')+'"'+q+'"'+(toHe?' לעברית?':' בשפה הלועזית?'),opts:opts,ans:opts.indexOf(ans),dir:'auto'});
    });
  }
  var mq=shuffle(qs).slice(0,8).map(function(q){var idx=q.opts.map(function(o,i){return i}),sh=shuffle(idx);return{src:'חומר לימוד',q:q.q,opts:sh.map(function(i){return q.opts[i]}),ans:sh.indexOf(q.ans),dir:'auto'}});
  var a=vq.slice(),b=mq.slice();
  while(out.length<5&&(a.length||b.length)){ if(a.length&&(out.length%2===0||!b.length))out.push(a.shift()); else if(b.length)out.push(b.shift()); }
  return out;
}
function startChallenge(){
  loadData().then(function(){
    var qs=buildQuestions();
    if(qs.length<3){
      openSheet('<h2>אין מספיק חומר</h2><p class="muted">כדי לשחק צריך לפחות 4 מילים במילון, או 3 שאלות במסלול. הוסף עוד קצת ונתחיל!</p><div class="btns"><button class="btn primary" data-go2="vocab:tr">להוסיף מילים</button><button class="btn" data-go2="maslul:prac">לשאלות במסלול</button></div>');
      $$('#panel [data-go2]').forEach(function(b){b.addEventListener('click',function(){var p=b.dataset.go2.split(':');closeSheet();go(p[0],p[1])})});
      return;
    }
    CH={qs:qs,i:0,ok:0,res:[],sel:null,first:daily().d!==ymd()};
    $('#full').hidden=false;drawChallenge();
  });
}
function drawChallenge(){
  var c=CH,q=c.qs[c.i],L=['א','ב','ג','ד'];
  var prog='<div class="prog">'+c.qs.map(function(_,i){return '<i class="'+(c.res[i]===1?'ok':c.res[i]===0?'no':i===c.i?'on':'')+'"></i>'}).join('')+'</div>';
  var top='<div class="row between"><button class="btn" data-ch="quit">יציאה</button><span class="src">'+esc(q.src)+' · '+(c.i+1)+'/'+c.qs.length+'</span></div>';
  var opts=q.opts.map(function(o,i){
    var cls='opt';if(c.sel!=null){if(i===q.ans)cls+=' ok';else if(i===c.sel)cls+=' no'}
    return '<button class="'+cls+'" data-opt="'+i+'" '+(c.sel!=null?'disabled':'')+'><span class="k">'+L[i]+'</span><span dir="auto">'+esc(o)+'</span></button>';
  }).join('');
  var fb='';
  if(c.sel!=null){fb='<div class="card" style="padding:12px 14px">'+(c.sel===q.ans?'נכון!':'התשובה הנכונה: <b dir="auto">'+esc(q.opts[q.ans])+'</b>')+'</div><button class="btn primary block" data-ch="next">'+(c.i+1>=c.qs.length?'לסיכום':'לשאלה הבאה')+'</button>'}
  $('#fullin').innerHTML=top+prog+'<div class="qt" dir="auto">'+esc(q.q)+'</div><div class="stack">'+opts+'</div>'+fb;
}
$('#fullin').addEventListener('click',function(e){
  var o=e.target.closest('[data-opt]'),b=e.target.closest('[data-ch]');
  if(o&&CH&&CH.sel==null){var i=+o.dataset.opt,q=CH.qs[CH.i];CH.sel=i;var ok=i===q.ans;CH.res[CH.i]=ok?1:0;if(ok)CH.ok++;drawChallenge();return}
  if(b){
    if(b.dataset.ch==='quit'){CH=null;$('#full').hidden=true;return}
    if(b.dataset.ch==='next'){CH.i++;CH.sel=null;if(CH.i>=CH.qs.length)endChallenge();else drawChallenge()}
    if(b.dataset.ch==='home'){CH=null;$('#full').hidden=true;go('home')}
  }
});
function endChallenge(){
  var c=CH,n=c.qs.length,pts=0,msg='';
  if(c.first){
    pts=c.ok*10+(c.ok===n?20:0);
    var d=daily(),y=ymd(new Date(Date.now()-864e5));
    var st=(d.d===y)?(d.streak||1)+1:1;
    lsSet('school.daily',JSON.stringify({d:ymd(),score:c.ok,of:n,streak:st}));
    if(pts>0)award(pts,'אתגר היום');
    msg='קיבלת '+pts+' נקודות'+(c.ok===n?' (כולל בונוס מושלם)':'')+'. רצף אתגרים: '+st;
  }else msg='סיבוב תרגול, בלי נקודות. הנקודות כבר נספרו היום.';
  var stars=c.ok===n?3:c.ok>=n-1?2:c.ok>=Math.ceil(n/2)?1:0;
  $('#fullin').innerHTML='<div style="height:20px"></div><div class="big">'+(stars===3?'מושלם!':stars===2?'כל הכבוד!':stars===1?'התחלה טובה':'עוד קצת תרגול')+'</div>'+
    '<div class="stars">'+[1,2,3].map(function(i){return '<span style="color:'+(i<=stars?'#F2B01E':'var(--line)')+'">'+STAR+'</span>'}).join('')+'</div>'+
    '<div style="text-align:center;font-size:18px">ענית נכון על <b>'+c.ok+'</b> מתוך '+n+'</div><div class="card" style="text-align:center">'+esc(msg)+'</div>'+
    '<div class="btns"><button class="btn primary" data-ch="home">חזרה לבית</button></div>';
}

/* ---------- חלון תחתון, הודעות ---------- */
function openSheet(html){$('#panel').innerHTML=html;$('#shade').hidden=false;$('#sheet').hidden=false}
function closeSheet(){$('#shade').hidden=true;$('#sheet').hidden=true;$('#panel').innerHTML=''}
$('#shade').addEventListener('click',closeSheet);
var tT;function toast(m){var t=$('#toast');t.innerHTML='<div>'+esc(m)+'</div>';t.hidden=false;clearTimeout(tT);tT=setTimeout(function(){t.hidden=true},2600)}

/* ---------- הגדרות וגיבוי ---------- */
$('#gear').addEventListener('click',function(){
  var inst=isStandalone()?'<p class="muted small" style="margin:0">האפליקציה מותקנת.</p>':deferred?'<button class="btn primary block" data-s="install">התקן כאפליקציה</button>':'<p class="muted small" style="margin:0">להתקנה: בכרום, תפריט ⋮ ואז "התקן אפליקציה". בספארי: שיתוף ואז "הוסף למסך הבית".</p>';
  openSheet('<h2>הגדרות</h2><div class="stack">'+
    '<div class="card stack"><b>התקנה</b>'+inst+'</div>'+
    '<div class="card stack"><b>גיבוי והעברה</b><p class="muted small" style="margin:0">הנתונים נשמרים על המכשיר הזה בלבד. כדאי לשמור גיבוי מדי פעם, ואפשר להעביר בעזרתו למכשיר אחר.</p>'+
      '<div class="btns"><button class="btn" data-s="export">הורד קובץ גיבוי</button><button class="btn" data-s="copy">העתק גיבוי כטקסט</button></div>'+
      '<label class="small muted" for="restoreTxt">שחזור: הדבק טקסט גיבוי</label><textarea id="restoreTxt" dir="ltr" placeholder="הדבק כאן"></textarea>'+
      '<div class="btns"><button class="btn primary" data-s="restoreTxt">שחזר מהטקסט</button><label class="btn" style="cursor:pointer">שחזר מקובץ<input id="restoreFile" type="file" accept=".json,application/json" hidden></label></div></div>'+
    '<div class="card stack"><b>מה עובד בלי אינטרנט</b><p class="muted small" style="margin:0">הכול עובד בלי רשת, חוץ מתרגום אוטומטי של מילים (צריך אינטרנט) ויצירה אוטומטית של שאלות וחידונים עם Claude, שזמינה רק כשהדף נפתח בתוך claude.ai.</p></div>'+
    '<div class="card stack"><b>איפוס</b><button class="btn danger" data-s="wipe">מחק את כל הנתונים</button></div>'+
    '<button class="btn block" data-s="close">סגור</button></div>');
});
$('#panel').addEventListener('click',function(e){
  var b=e.target.closest('[data-s]');if(!b)return;var a=b.dataset.s;
  if(a==='close')closeSheet();
  else if(a==='install')doInstall();
  else if(a==='export')collect().then(function(j){if(window.AndroidBridge&&window.AndroidBridge.shareText){window.AndroidBridge.shareText('maslul-backup-'+ymd()+'.json',JSON.stringify(j));return}var blob=new Blob([JSON.stringify(j)],{type:'application/json'}),u=URL.createObjectURL(blob),l=document.createElement('a');l.href=u;l.download='maslul-backup-'+ymd()+'.json';document.body.appendChild(l);l.click();setTimeout(function(){URL.revokeObjectURL(u);l.remove()},3000);toast('הגיבוי ירד')});
  else if(a==='copy')collect().then(function(j){var t=JSON.stringify(j);(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(function(){toast('הגיבוי הועתק')},function(){var ta=$('#restoreTxt');ta.value=t;ta.select();toast('סמן והעתק ידנית')})});
  else if(a==='restoreTxt')restore($('#restoreTxt').value);
  else if(a==='wipe'){if(confirm('למחוק את כל הנתונים של האפליקציה מהמכשיר הזה? אי אפשר לבטל.'))wipeAll()}
});
document.addEventListener('change',function(e){
  if(e.target&&e.target.id==='restoreFile'&&e.target.files[0]){var r=new FileReader();r.onload=function(){restore(String(r.result))};r.readAsText(e.target.files[0])}
});
function collect(){
  return Promise.all([ask('maslul',{t:'dump'}),ask('vocab',{t:'dump'})]).then(function(r){
    return{kind:'maslul-backup',v:1,at:new Date().toISOString(),maslul:r[0]&&r[0].data||null,vocab:r[1]&&r[1].data||null,daily:lsGet('school.daily')};
  });
}
function restore(text){
  var j;try{j=JSON.parse(String(text).trim())}catch(e){toast('הטקסט לא נראה כמו גיבוי');return}
  var m=null,v=null,d=null;
  if(j&&j.kind==='maslul-backup'){m=j.maslul;v=j.vocab;d=j.daily}
  else if(j&&Array.isArray(j.subjects))m=JSON.stringify(j);
  else if(j&&j.words&&j.folders)v=JSON.stringify(j);
  else{toast('לא זיהיתי את סוג הגיבוי');return}
  if(!m&&!v){toast('בגיבוי אין נתונים');return}
  if(!confirm('לשחזר? הנתונים הקיימים של החלקים שבגיבוי יוחלפו.'))return;
  var jobs=[];
  if(m){ready.maslul=false;jobs.push(ask('maslul',{t:'restore',data:m}))}
  if(v){ready.vocab=false;jobs.push(ask('vocab',{t:'restore',data:v}))}
  if(d)lsSet('school.daily',d);
  Promise.all(jobs).then(function(){closeSheet();toast('שוחזר בהצלחה');setTimeout(function(){go(VIEW)},700)});
}
function wipeAll(){
  ready.maslul=false;ready.vocab=false;
  Promise.all([ask('maslul',{t:'wipe'}),ask('vocab',{t:'wipe'})]).then(function(){lsDel('school.daily');lsDel('school.view');closeSheet();toast('הכול נמחק');setTimeout(function(){go('home')},700)});
}

/* ---------- התחלה ---------- */
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){
  window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})});
}
go('home');
// קיצורי דרך מהאייקון (לחיצה ארוכה): index.html?go=challenge או go=maslul:time
(function(){
  var q=''; try{q=new URLSearchParams(location.search).get('go')||''}catch(e){}
  if(!q)return;
  if(q==='challenge'){Promise.all([waitReady('maslul'),waitReady('vocab')]).then(startChallenge)}
  else{var p=q.split(':');if(p[0]==='maslul'||p[0]==='vocab'||p[0]==='report')go(p[0],p[1])}
})();
})();

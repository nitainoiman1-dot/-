/* חלק של "מסלול" בגשר: סיכום נתונים למסך הבית והתעודה, והוספת נקודות מבחוץ. */
(function(){
  'use strict';
  window.__award=function(n,why){
    n=Math.round(+n||0); if(n<=0)return;
    var got=addXP(n); save();
    if(typeof toast==='function')toast('+'+got+' נקודות'+(why?' · '+why:''));
    render();
  };
  window.__summary=function(){
    var nd=nowD(),ti=ymd(nd),tk=tasksOn(ti),st=todayTasks();
    var total=tk.length+st.open.length+st.done.length;
    var done=tk.filter(function(t){return t.done}).length+st.done.length;
    var lv=lvlOf(S.xp),si=schoolIdx(nd),lesson=null;
    try{
      if(si>=0&&S.bells&&S.bells.start){
        var c=curLesson(si),day=c.day;
        if(c.nowI>=0)lesson={k:'now',name:lname(day[c.nowI]),left:slot(c.nowI).e-c.now};
        else if(c.nextI>=0){var s=slot(c.nextI);lesson={k:'next',name:lname(day[c.nextI]),in:s.s-c.now,at:hm(s.s)};}
        else lesson={k:'over'};
      }
    }catch(e){}
    var exams=S.subjects.filter(function(s){return s.kind!=='pop'&&daysLeft(s)>=0}).sort(function(a,b){return a.exam<b.exam?-1:1}).slice(0,4)
      .map(function(s){return{id:s.id,name:s.name,days:daysLeft(s),color:s.color}});
    var subjects=S.subjects.filter(function(s){return s.kind!=='pop'}).map(function(s){
      return{name:s.name,color:s.color,ready:readiness(s),days:daysLeft(s),topics:s.topics.length};
    });
    var qs=S.qs.filter(function(q){return Array.isArray(q.opts)&&q.opts.length>=2&&Number.isInteger(q.ans)&&q.t!=='fill'}).slice(0,80)
      .map(function(q){return{q:q.q,opts:q.opts,ans:q.ans}});
    return{
      pts:S.pts||0,xp:S.xp||0,lvl:lv,lvlName:lvlName(lv),streak:streak(),
      total:total,done:done,lesson:lesson,exams:exams,subjects:subjects,qs:qs,
      due:dueCards().length,badges:Object.keys(S.badges||{}).length,
      reviews:(S.stat&&S.stat.reviews)||0,correct:(S.stat&&S.stat.correct)||0,focus:(S.stat&&S.stat.focus)||0,
      boost:boostOn(),day:si
    };
  };
})();
